import pickle
from loaded_models import decision_tree, naive_bayes
from flask import Flask, render_template, request
import numpy as np
from sklearn import tree
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from flask import Flask,request,render_template,redirect
import pickle

app = Flask(__name__)
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/', methods = ['POST'])
def getvalue():
    try:
        smp1 = request.form['smp1']
        smp2 = request.form['smp2']
        smp3 = request.form['smp3']
        smp4 = request.form['smp4']
        smp5 = request.form['smp5']
        dt = decision_tree(smp1, smp2, smp3, smp4, smp5)
        nb = naive_bayes(smp1, smp2, smp3, smp4, smp5)
        p1 = dt
        p2 = nb
        return render_template('result.html',p1 = p1, p2 = p2, smp1 = smp1, smp2 = smp2, smp3 = smp3, smp4 = smp4, smp5 =smp5)
    except:
        pass

@app.route('/contact')
def contact():
    return render_template('Contact-Us.html')

@app.route('/about')
def about():
    return render_template('About.html')

@app.route('/logout')
def logout():
    return redirect('http://localhost/login/index.php')

@app.route('/register')
def register():
    return render_template('register.php')

if __name__ == "__main__":
    app.run(debug=True)