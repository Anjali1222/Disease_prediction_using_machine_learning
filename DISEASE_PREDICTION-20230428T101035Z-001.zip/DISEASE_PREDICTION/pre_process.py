{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 13,
   "metadata": {},
   "outputs": [],
   "source": [
    "from tkinter import *\n",
    "import numpy as np\n",
    "import pandas as pd\n",
    "from sklearn import tree\n",
    "from sklearn.metrics import accuracy_score\n",
    "from sklearn.naive_bayes import GaussianNB\n",
    "from sklearn.metrics import accuracy_score\n",
    "from flask import Flask,request,render_template\n",
    "import pickle"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {},
   "outputs": [],
   "source": [
    "l1=['back_pain','constipation','abdominal_pain','diarrhoea','mild_fever','yellow_urine',\n",
    "'yellowing_of_eyes','acute_liver_failure','fluid_overload','swelling_of_stomach',\n",
    "'swelled_lymph_nodes','malaise','blurred_and_distorted_vision','phlegm','throat_irritation',\n",
    "'redness_of_eyes','sinus_pressure','runny_nose','congestion','chest_pain','weakness_in_limbs',\n",
    "'fast_heart_rate','pain_during_bowel_movements','pain_in_anal_region','bloody_stool',\n",
    "'irritation_in_anus','neck_pain','dizziness','cramps','bruising','obesity','swollen_legs',\n",
    "'swollen_blood_vessels','puffy_face_and_eyes','enlarged_thyroid','brittle_nails',\n",
    "'swollen_extremeties','excessive_hunger','extra_marital_contacts','drying_and_tingling_lips',\n",
    "'slurred_speech','knee_pain','hip_joint_pain','muscle_weakness','stiff_neck','swelling_joints',\n",
    "'movement_stiffness','spinning_movements','loss_of_balance','unsteadiness',\n",
    "'weakness_of_one_body_side','loss_of_smell','bladder_discomfort','foul_smell_of urine',\n",
    "'continuous_feel_of_urine','passage_of_gases','internal_itching','toxic_look_(typhos)',\n",
    "'depression','irritability','muscle_pain','altered_sensorium','red_spots_over_body','belly_pain',\n",
    "'abnormal_menstruation','dischromic _patches','watering_from_eyes','increased_appetite','polyuria','family_history','mucoid_sputum',\n",
    "'rusty_sputum','lack_of_concentration','visual_disturbances','receiving_blood_transfusion',\n",
    "'receiving_unsterile_injections','coma','stomach_bleeding','distention_of_abdomen',\n",
    "'history_of_alcohol_consumption','fluid_overload','blood_in_sputum','prominent_veins_on_calf',\n",
    "'palpitations','painful_walking','pus_filled_pimples','blackheads','scurring','skin_peeling',\n",
    "'silver_like_dusting','small_dents_in_nails','inflammatory_nails','blister','red_sore_around_nose',\n",
    "'yellow_crust_ooze']"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "metadata": {},
   "outputs": [],
   "source": [
    "disease=['Fungal infection','Allergy','GERD','Chronic cholestasis','Drug Reaction',\n",
    "'Peptic ulcer diseae','AIDS','Diabetes','Gastroenteritis','Bronchial Asthma','Hypertension',\n",
    "' Migraine','Cervical spondylosis',\n",
    "'Paralysis (brain hemorrhage)','Jaundice','Malaria','Chicken pox','Dengue','Typhoid','hepatitis A',\n",
    "'Hepatitis B','Hepatitis C','Hepatitis D','Hepatitis E','Alcoholic hepatitis','Tuberculosis',\n",
    "'Common Cold','Pneumonia','Dimorphic hemmorhoids(piles)',\n",
    "'Heartattack','Varicoseveins','Hypothyroidism','Hyperthyroidism','Hypoglycemia','Osteoarthristis',\n",
    "'Arthritis','(vertigo) Paroymsal  Positional Vertigo','Acne','Urinary tract infection','Psoriasis',\n",
    "'Impetigo']"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "metadata": {},
   "outputs": [],
   "source": [
    "l2=[]\n",
    "for x in range(0,len(l1)):\n",
    "    l2.append(0)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "metadata": {},
   "outputs": [],
   "source": [
    "df=pd.read_csv(\"Training.csv\") #load training csv\n",
    "tr=pd.read_csv(\"Testing.csv\")  #load testing csv\n",
    "\n",
    "#print(df)\n",
    "#print(tr)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "metadata": {},
   "outputs": [],
   "source": [
    "#prognosis is a column name of label\n",
    "#converting labels into numeric value\n",
    "\n",
    "df.replace({'prognosis':{'Fungal infection':0,'Allergy':1,'GERD':2,'Chronic cholestasis':3,'Drug Reaction':4,\n",
    "'Peptic ulcer diseae':5,'AIDS':6,'Diabetes ':7,'Gastroenteritis':8,'Bronchial Asthma':9,'Hypertension ':10,\n",
    "'Migraine':11,'Cervical spondylosis':12,\n",
    "'Paralysis (brain hemorrhage)':13,'Jaundice':14,'Malaria':15,'Chicken pox':16,'Dengue':17,'Typhoid':18,'hepatitis A':19,\n",
    "'Hepatitis B':20,'Hepatitis C':21,'Hepatitis D':22,'Hepatitis E':23,'Alcoholic hepatitis':24,'Tuberculosis':25,\n",
    "'Common Cold':26,'Pneumonia':27,'Dimorphic hemmorhoids(piles)':28,'Heart attack':29,'Varicose veins':30,'Hypothyroidism':31,\n",
    "'Hyperthyroidism':32,'Hypoglycemia':33,'Osteoarthristis':34,'Arthritis':35,\n",
    "'(vertigo) Paroymsal  Positional Vertigo':36,'Acne':37,'Urinary tract infection':38,'Psoriasis':39,\n",
    "'Impetigo':40}},inplace=True)\n",
    "\n",
    "tr.replace({'prognosis':{'Fungal infection':0,'Allergy':1,'GERD':2,'Chronic cholestasis':3,'Drug Reaction':4,\n",
    "'Peptic ulcer diseae':5,'AIDS':6,'Diabetes ':7,'Gastroenteritis':8,'Bronchial Asthma':9,'Hypertension ':10,\n",
    "'Migraine':11,'Cervical spondylosis':12,\n",
    "'Paralysis (brain hemorrhage)':13,'Jaundice':14,'Malaria':15,'Chicken pox':16,'Dengue':17,'Typhoid':18,'hepatitis A':19,\n",
    "'Hepatitis B':20,'Hepatitis C':21,'Hepatitis D':22,'Hepatitis E':23,'Alcoholic hepatitis':24,'Tuberculosis':25,\n",
    "'Common Cold':26,'Pneumonia':27,'Dimorphic hemmorhoids(piles)':28,'Heart attack':29,'Varicose veins':30,'Hypothyroidism':31,\n",
    "'Hyperthyroidism':32,'Hypoglycemia':33,'Osteoarthristis':34,'Arthritis':35,\n",
    "'(vertigo) Paroymsal  Positional Vertigo':36,'Acne':37,'Urinary tract infection':38,'Psoriasis':39,\n",
    "'Impetigo':40}},inplace=True)\n",
    "\n",
    "#print(df)\n",
    "#print(tr)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 7,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,\n",
       "       17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33,\n",
       "       34, 35, 36, 37, 38, 39, 40], dtype=int64)"
      ]
     },
     "execution_count": 7,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "#np.ravel is used to change a 2-dimensional array or a multi-dimensional array into a contiguous flattened array\n",
    "\n",
    "X_train= df[l1]\n",
    "y_train = df[[\"prognosis\"]]\n",
    "np.ravel(y_train)\n",
    "\n",
    "X_test= tr[l1]\n",
    "y_test = tr[[\"prognosis\"]]\n",
    "np.ravel(y_test)\n",
    "\n",
    "#print(y_train)\n",
    "#print(y_test)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 37,
   "metadata": {},
   "outputs": [],
   "source": [
    "classification_DT = tree.DecisionTreeClassifier()\n",
    "classification_DT = classification_DT.fit(X_train,y_train)\n",
    "filename = 'Decision_tree.sav'\n",
    "pickle.dump(classification_DT, open(filename, 'wb'))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 38,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "[18]\n",
      "Typhoid\n",
      "0.9512195121951219\n"
     ]
    }
   ],
   "source": [
    "def decision_tree(smp1 = \" \", smp2 = \" \", smp3 = \" \", smp4 = \" \", smp5 = \" \"):\n",
    "\n",
    "    loaded_model = pickle.load(open(filename, 'rb'))\n",
    "\n",
    "    psymptoms = [smp1, smp2, smp3, smp4, smp5]\n",
    "\n",
    "    for k in range(0,len(l1)):\n",
    "        # print (k,)\n",
    "        for z in psymptoms:\n",
    "            if(z==l1[k]):\n",
    "                l2[k]=1\n",
    "\n",
    "    #print(l2)\n",
    "\n",
    "\n",
    "\n",
    "    inputtest = [l2]\n",
    "    predict = loaded_model.predict(inputtest)\n",
    "    print(predict)\n",
    "    predicted=predict[0]\n",
    "\n",
    "    h='no'\n",
    "    for a in range(0,len(disease)):\n",
    "        if(predicted == a):\n",
    "            h='yes'\n",
    "            break\n",
    "\n",
    "\n",
    "    if (h=='yes'):\n",
    "        return disease[a]\n",
    "    else:\n",
    "        return \"Not Found\"\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 39,
   "metadata": {},
   "outputs": [],
   "source": [
    "gnb = GaussianNB()\n",
    "gnb=gnb.fit(X_train,np.ravel(y_train))\n",
    "filename = 'Naive_bayes.sav'\n",
    "pickle.dump(gnb, open(filename, 'wb'))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 40,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "[18]\n",
      "Typhoid\n",
      "0.9512195121951219\n"
     ]
    }
   ],
   "source": [
    "loaded_model = pickle.load(open(filename, 'rb'))\n",
    "\n",
    "psymptoms = ['back_pain','constipation','abdominal_pain','diarrhoea','mild_fever']\n",
    "for k in range(0,len(l1)):\n",
    "    for z in psymptoms:\n",
    "        if(z==l1[k]):\n",
    "            l2[k]=1\n",
    "#print(l2)\n",
    "\n",
    "inputtest = [l2]\n",
    "predict = loaded_model.predict(inputtest)\n",
    "print(predict)\n",
    "predicted=predict[0]\n",
    "\n",
    "h='no'\n",
    "for a in range(0,len(disease)):\n",
    "    if(predicted == a):\n",
    "        h='yes'\n",
    "        break\n",
    "\n",
    "if (h=='yes'):\n",
    "    print(disease[a])\n",
    "else:\n",
    "    print(\"Not Found\")\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      " * Serving Flask app \"__main__\" (lazy loading)\n",
      " * Environment: production\n",
      "   WARNING: This is a development server. Do not use it in a production deployment.\n",
      "   Use a production WSGI server instead.\n",
      " * Debug mode: off\n"
     ]
    },
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      " * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)\n",
      "127.0.0.1 - - [29/May/2021 14:17:33] \"\u001b[37mGET / HTTP/1.1\u001b[0m\" 200 -\n",
      "127.0.0.1 - - [29/May/2021 14:17:41] \"\u001b[37mPOST / HTTP/1.1\u001b[0m\" 200 -\n"
     ]
    }
   ],
   "source": [
    "'''app = Flask(__name__)\n",
    "\n",
    "@app.route('/')\n",
    "def Hello():\n",
    "     return render_template('index.html')\n",
    "    \n",
    "if __name__ == '__main__':\n",
    "    app.run()\n",
    "    \n",
    "'''\n",
    "    \n",
    "    \n",
    "    \n",
    "app = Flask(__name__)   \n",
    "  \n",
    "# A decorator used to tell the application\n",
    "# which URL is associated function\n",
    "@app.route('/', methods =[\"GET\", \"POST\"])\n",
    "def gfg():\n",
    "    if request.method == \"POST\":\n",
    "        # getting input with name = fname in HTML form\n",
    "        first_name = request.form.get(\"fname\")\n",
    "        # getting input with name = lname in HTML form \n",
    "        last_name = request.form.get(\"lname\") \n",
    "        return \"Your name is \"+first_name + last_name\n",
    "    return render_template(\"index.html\")\n",
    "  \n",
    "if __name__=='__main__':\n",
    "    app.run()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.7.3"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 2
}